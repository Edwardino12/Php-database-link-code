<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <title>Compte Administrateur</title>
        <div id="right-panel" class="right-panel">
    </head>
    <body>
        <aside id="left-panel" class="left-panel">
            <nav class="navbar">
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu">
                    <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="#"></a>
                    <a class="navbar-brand hidden" href="#"></a>
                </div>
                <div id="main-menu" class="main-menu collapse navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li>
                            <a href="dashboard-admin.php"><i class="menu-icon fa fa-dashboard">Mon Compte</i></a>
                        </li>
                        <li>
                            <a href="exam_category.php"><i class="menu-icon fa fa-dashboard">Ajouter et Modifier Evaluation</i></a>
                        </li>
                        <li>
                            <a href="Login-admin.php"><i class="menu-icon fa fa-close">Deconnexion</i></a>
                        </li>
                    </ul>
                </div>
            </nav>
        </aside>
        <div id="right-panel" class="right-panel">
    <header id="header" class="header">
        <div class="header-menu">
            <div class="col-sm-7">

            </div>
            <div class="col-sm-5">
                <div class="user area dropdown float-right">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img class="user-avatar round-circle" src="c.jpg" alt="User Avatar">
                    </a>
                    <div class="user-menu dropdown-menu">
                        <a class="nav-link" href="Login-admin.php"><i class="fa fa-power-off"></i>Deconnexion</a>
                    </div>
                </div>
            </div>
        </div>
    </header>

