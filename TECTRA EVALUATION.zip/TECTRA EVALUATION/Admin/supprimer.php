<?php
include "../config.php";
$Id=$_GET["id"];
mysqli_query($conn,"delete from exam_category where Id=$Id");

?>
<script type="text/javascript">
    window.location="exam_category.php";
</script>