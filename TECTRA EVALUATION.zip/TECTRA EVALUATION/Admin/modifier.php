<?php
include "header.php";
include "../config.php";
$Id=$_GET["id"];
$res=mysqli_query($conn,"select * from exam_category where Id=$Id");
while($row=mysqli_fetch_array($res))
{
    $exam_category=$row["categorie"];
    $exam_time=$row["temps_evaluation"];
}
?>
    <div class="breadcrumbs">
        <div class="col-sm-4">
            <div class="page-header float-left">
                <div class="page-title">
                    <h1>Modifier Categorie</h1>
                </div>
            </div>
        </div>
    </div>

    <div class="content mt-3">
        <div class="animated fadein">

            <div class="row">
                <div class="col-lg-l2">
                    <div class="exam-form">
                        <form name="form2" action="" method="post">
                        <div class="exam-form-body">
                            <div class="col-lg-6">
                                <div class="card">
                                    <div class="card-header"><strong>Evaluation</strong>

                                    </div>
                                        <div class="card-body card-block">
                                            <div class="form-group">
                                            <label for="exam_category" class="form-control-label">Categorie d'Evaluation
                                                <input type="text" placeholder="Ajouter Categorie" class="form-control" name="examcategory" value="<?php echo $exam_category; ?>">
                                            </label>

                                        </div>
                                            <div class="form-group">
                                                <label for="exam_time" class="form-control-label">Duree de l'Evaluation
                                                <input type="text" placeholder="Duree de l'Evaluation" class="form-control" name="examtime" value="<?php echo $exam_time; ?>">
                                                </label>

                                            </div>
                                                <div class="form-group">
                                                    <input type="submit" name="submit2" value="Modifier Evaluation" class="btn btn-success">

                                                </div>                                 
                                </div> 
                            </div>
                            
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
if(isset($_POST["submit2"]))
{
    mysqli_query($conn,"update exam_category set categorie='$_POST[examcategory]',temps_evaluation='$_POST[examtime]' where Id=$Id") or die(mysqli_error($conn));
    ?>
    <script type="text/javascript">

        window.location="exam_category.php";
    </script>
    <?php

}
?>

    <?php
    include "footer.php";
    ?>