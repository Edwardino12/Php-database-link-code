<?php
include "../config.php";


?>

<!DOCTYPE html>
  <html class="no-js" lang="fr">
   <head>
       <meta charset="utf-8">
       <title>Administrateur</title>
   </head> 
   <body class="background">
    
   <div class="login-admin">
      <div class="container">
        <div class="login-content">
          <div class="login-logo">
            Connexion Administrateur
          </div>
          <div class="login-form">
            <form name="form1" action="" method="post">
              <div class="form-group">
                <label>Nom d'Utilisateur</label>
                <input type="text" name="utilisateur" class="form-control" placeholder="Veillez entrer votre nom d'utilisateur" required="required">

              </div>
              <div class="form-group">
              <label>Mot de Passe</label>
              <input type="password" name="passwo" class="form-control" placeholder="Veillez saisir votre mot de passe" required="required"> 
              </div>
            <button type="submit" name="submit1" class="btn btn-success">Sign-in</button>

              <div class="alert alert-danger" id="errormsg" style="margin-top: 10px; display: none">
              <strong>Invalide!</strong>Utilisteur ou Mot de Passe Invalide
            </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    
   </body>
  </html>
<?php
if (isset($_POST["submit1"])){

  $count=0;
  $utilisateur=mysqli_real_escape_string($conn,$_POST["utilisateur"]);
  $passwo=mysqli_real_escape_string($conn,$_POST["passwo"]);

  $res=mysqli_query($conn,"select * from adminpanel where Utilisateur='$utilisateur' && MotdePasse ='$passwo'");
  $count=mysqli_num_rows($res);
  if($count==0){
    ?>
    <script type="text/javascript">
      document.getElementById(errormsg).style.display="block";
    </script>
    <?php
    
  }
  else{
    ?>
    <script type="text/javascript">
      window.location="dashboard-admin.php";
    </script>
    <?php
  }
}
?>